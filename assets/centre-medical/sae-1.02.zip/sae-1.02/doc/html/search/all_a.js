var searchData=
[
  ['recherchelineairepatient_0',['rechercheLineairePatient',['../sae_8h.html#accc5f8850c872d822e7991d8a1f5ce5a',1,'sae.c']]],
  ['rechercherspecialite_1',['rechercherSpecialite',['../sae_8h.html#a8083332d4d13136eb22654f1f3323223',1,'sae.c']]]
];
