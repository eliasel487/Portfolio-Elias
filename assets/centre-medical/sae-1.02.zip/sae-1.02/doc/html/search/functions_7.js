var searchData=
[
  ['praticienpeutprendrepatient_0',['praticienPeutPrendrePatient',['../sae_8h.html#aad8a95fca1bd6edcb6495469c59ec089',1,'sae.c']]]
];
