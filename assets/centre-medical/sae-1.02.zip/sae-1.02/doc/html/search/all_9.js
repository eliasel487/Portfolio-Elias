var searchData=
[
  ['patient_0',['Patient',['../struct_patient.html',1,'']]],
  ['patientele_1',['Patientele',['../struct_patientele.html',1,'']]],
  ['praticien_2',['Praticien',['../struct_praticien.html',1,'']]],
  ['praticienpeutprendrepatient_3',['praticienPeutPrendrePatient',['../sae_8h.html#aad8a95fca1bd6edcb6495469c59ec089',1,'sae.c']]]
];
