var searchData=
[
  ['patient_0',['Patient',['../struct_patient.html',1,'']]],
  ['patientele_1',['Patientele',['../struct_patientele.html',1,'']]],
  ['praticien_2',['Praticien',['../struct_praticien.html',1,'']]]
];
