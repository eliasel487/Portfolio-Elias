var annotated_dup =
[
    [ "CentreMedical", "struct_centre_medical.html", null ],
    [ "Date", "struct_date.html", null ],
    [ "File", "struct_file.html", null ],
    [ "Maillon", "struct_maillon.html", null ],
    [ "maillon", "structmaillon.html", null ],
    [ "MaillonPraticien", "struct_maillon_praticien.html", null ],
    [ "Patient", "struct_patient.html", null ],
    [ "Patientele", "struct_patientele.html", null ],
    [ "Praticien", "struct_praticien.html", null ],
    [ "Specialite", "struct_specialite.html", null ]
];